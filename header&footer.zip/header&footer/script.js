function toggleProducts() {
  let productSection = document.getElementById('product-section');

  const displayStyle = window.getComputedStyle(productSection).display;

  if (displayStyle === 'none') {
    productSection.style.display = 'flex';
  } else {
    productSection.style.display = 'none';
  }
}
